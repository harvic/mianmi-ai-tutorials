"""生成三种来源、三套表头的「乱账单」（演示用，固定随机种子可复现）。
乱点：每个来源列名不同、日期格式不同、金额带 ¥／逗号／正负号规则不同、有退款、有重复导出行、
      银行卡账单里包含「财付通-微信支付」代扣记录（与微信账单是同一笔，直接相加会重复计入）。
"""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

random.seed(20260908)
raw = Path(__file__).resolve().parent.parent / "data" / "raw"
raw.mkdir(parents=True, exist_ok=True)

MERCHANTS = {
    "餐饮": ["美团外卖", "饿了么", "山野茶铺", "老王牛肉面", "瑞幸咖啡", "社区菜场-李记蔬菜"],
    "交通": ["地铁出行", "滴滴出行", "公交一卡通充值", "中国石化加油站"],
    "购物": ["京东商城", "淘宝-家居旗舰店", "拼多多", "永辉超市", "屈臣氏"],
    "居住": ["城南物业费", "国家电网-电费", "自来水公司", "燃气公司", "房租-张女士"],
    "娱乐": ["猫眼电影", "视频会员自动续费", "社区游泳馆"],
    "医疗": ["同仁堂药房", "社区卫生服务中心"],
}
ALL = [(cat, m) for cat, ms in MERCHANTS.items() for m in ms]


def rand_amount(cat):
    base = {"餐饮": (12, 120), "交通": (3, 300), "购物": (20, 800), "居住": (50, 2600), "娱乐": (15, 90), "医疗": (20, 260)}[cat]
    return round(random.uniform(*base), 2)


def month_days(y, m):
    d = date(y, m, 1)
    while d.month == m:
        yield d
        d += timedelta(days=1)


for (y, m) in ((2026, 7), (2026, 8)):
    wechat, alipay, bank = [], [], []
    for d in month_days(y, m):
        for _ in range(random.randint(1, 4)):
            cat, merchant = random.choice(ALL)
            amt = rand_amount(cat)
            hh, mm = random.randint(7, 22), random.randint(0, 59)
            channel = random.choices(["wechat", "alipay", "bank"], weights=[5, 3, 2])[0]
            if channel == "wechat":
                wechat.append([f"{d:%Y-%m-%d} {hh:02d}:{mm:02d}:{random.randint(0,59):02d}", "商户消费", merchant, "商品", "支出", f"¥{amt:.2f}", random.choice(["零钱", "工商银行储蓄卡(1234)"]), "支付成功"])
                # 用银行卡付款的微信订单，银行账单里会再出现一次代扣记录
                if wechat[-1][6].startswith("工商银行"):
                    bank.append([f"{d:%Y%m%d}", f"财付通-微信支付-{merchant}", f"-{amt:.2f}", "", "财付通支付科技有限公司"])
            elif channel == "alipay":
                alipay.append([f"{d:%Y/%m/%d} {hh}:{mm:02d}", merchant, "订单", f"{amt:,.2f}", random.choice(["余额宝", "花呗"]), "交易成功", "支出"])
            else:
                bank.append([f"{d:%Y%m%d}", merchant, f"-{amt:.2f}", "", merchant])
    # 退款：挑几笔支付宝／微信记录生成对应的收入行
    for r in random.sample(alipay, 2):
        alipay.append([r[0], r[1], "退款-" + r[2], r[3], r[4], "退款成功", "收入"])
    for r in random.sample(wechat, 2):
        wechat.append([r[0], "退款", r[2], "退款", "收入", r[5], r[6], "已全额退款"])
    # 工资入账与重复导出行
    bank.append([f"{y}{m:02d}10", "工资", "12,000.00", "", "示例科技有限公司"])
    bank.extend(random.sample(bank, 2))
    wechat.extend(random.sample(wechat, 3))

    with (raw / f"微信支付账单_{y}{m:02d}.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["微信支付账单明细列表（导出时间 2026-09-01）"])
        w.writerow(["交易时间", "交易类型", "交易对方", "商品", "收/支", "金额(元)", "支付方式", "当前状态"])
        w.writerows(wechat)
    with (raw / f"支付宝账单_{y}{m:02d}.csv").open("w", newline="", encoding="gbk") as f:
        w = csv.writer(f)
        w.writerow(["交易创建时间", "交易对方", "商品名称", "金额（元）", "收/付款方式", "交易状态", "收/支"])
        w.writerows(alipay)
    with (raw / f"银行卡账单_{y}{m:02d}.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["交易日期", "摘要", "交易金额", "余额", "对方户名"])
        w.writerows(bank)
    print(f"{y}-{m:02d}：微信 {len(wechat)} 行、支付宝 {len(alipay)} 行（GBK 编码）、银行 {len(bank)} 行（含微信代扣重复与工资）")
